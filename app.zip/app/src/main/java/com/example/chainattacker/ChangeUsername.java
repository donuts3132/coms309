package com.example.chainattacker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class ChangeUsername extends AppCompatActivity {
    int id;
    String username;
    int leaderboardid;
    int userlevel;
    String newusername;
    int partyid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_username);

        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        id = intent.getIntExtra("id", -1);
        leaderboardid = intent.getIntExtra("leaderboardid", -1);
        userlevel = intent.getIntExtra("userlevel", 1);
        partyid = intent.getIntExtra("partyid", -1);

        Button back = (Button) findViewById(R.id.backcu);
        Button cu = (Button) findViewById(R.id.changeu);
        EditText newu = (EditText) findViewById(R.id.newu);
        TextView currentu = (TextView) findViewById(R.id.currentu);

        currentu.setText("Current Username: " + username);

        cu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                newusername = newu.getText().toString();
                if (newusername.length() < 3) {
                    Toast.makeText(ChangeUsername.this, "Please enter a username longer than 3 characters", Toast.LENGTH_SHORT).show();
                }
                else {

                    RequestQueue queue = Volley.newRequestQueue(ChangeUsername.this);
                    JsonObjectRequest requesto = new JsonObjectRequest(Request.Method.PUT, "http://coms-309-058.class.las.iastate.edu:8080/updateUsername/" + id + "/" + newusername, null,
                            new Response.Listener<JSONObject>() {
                                @Override
                                public void onResponse (JSONObject response) {
                                    try {
                                        username = response.get("name").toString();
                                        currentu.setText("Current Username: " + username);
                                        newu.setText("");
                                        Toast.makeText(ChangeUsername.this, "Success", Toast.LENGTH_SHORT).show();
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            Toast.makeText(ChangeUsername.this, "Failed to contact server", Toast.LENGTH_SHORT).show();
                            error.printStackTrace();

                        }
                    });
                    queue.add(requesto);
                }
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(ChangeUsername.this, Settings.class);

                intent1.putExtra("username", username);
                intent1.putExtra("id", id);
                intent1.putExtra("leaderboardid", leaderboardid);
                intent1.putExtra("userlevel", userlevel);
                intent1.putExtra("partyid", partyid);
                startActivity(intent1);
            }
        });
    }
}