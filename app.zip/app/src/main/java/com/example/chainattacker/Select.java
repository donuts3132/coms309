package com.example.chainattacker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Select extends AppCompatActivity {
    ArrayList<String> listItems=new ArrayList<String>();
    JSONArray x;
    String username;
    int id;
    int leaderboardid;
    int userlevel;
    String Susername;
    int Sid;
    int Slid;
    int whereto;
    int Sul;
    int partyid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select);

        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        id = intent.getIntExtra("id", -1);
        leaderboardid = intent.getIntExtra("leaderboardid", -1);
        userlevel = intent.getIntExtra("userlevel", 1);
        whereto = intent.getIntExtra("whereto", -1);
        partyid = intent.getIntExtra("partyid", -1);

        ListView y = (ListView) findViewById(R.id.George);
        Button back = (Button) findViewById(R.id.button5);
        //DEFINING A STRING ADAPTER WHICH WILL HANDLE THE DATA OF THE LISTVIEW

        RequestQueue queue = Volley.newRequestQueue(Select.this);
        String url = "http://coms-309-058.class.las.iastate.edu:8080/getAll";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                x = response;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject a = response.getJSONObject(i);
                        String s = a.getString("name");
                        int j = a.getInt("id");
                        listItems.add("id: " + j + " Name: " + s);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
                ArrayAdapter<String> adapter1;

                adapter1 = new ArrayAdapter<String>(Select.this, R.layout.activity_listview, listItems);
                y.setAdapter(adapter1);




            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        queue.add(jsonArrayRequest);

        y.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    JSONObject a = x.getJSONObject(i);
                    Susername = a.getString("name");
                    Sid = a.getInt("id");
                    Slid = a.getJSONObject("leaderboard").getInt("boardId");
                    Sul = a.getInt("userLevel");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (whereto == 1) {
                    Intent intent = new Intent(Select.this, Promote.class);

                    intent.putExtra("username", username);
                    intent.putExtra("id", id);
                    intent.putExtra("leaderboardid", leaderboardid);
                    intent.putExtra("userlevel", userlevel);
                    intent.putExtra("Susername", Susername);
                    intent.putExtra("Sid", Sid);
                    intent.putExtra("Sul", Sul);
                    intent.putExtra("partyid", partyid);
                    startActivity(intent);
                }
                else {
                    Intent intent = new Intent(Select.this, changeleaderboard.class);
                    intent.putExtra("username", username);
                    intent.putExtra("id", id);
                    intent.putExtra("leaderboardid", leaderboardid);
                    intent.putExtra("userlevel", userlevel);
                    intent.putExtra("Susername", Susername);
                    intent.putExtra("Sid", Sid);
                    intent.putExtra("Slid", Slid);
                    intent.putExtra("partyid", partyid);
                    startActivity(intent);
                }
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Select.this, AdminSettings.class);

                intent.putExtra("username", username);
                intent.putExtra("id", id);
                intent.putExtra("leaderboardid", leaderboardid);
                intent.putExtra("userlevel", userlevel);
                intent.putExtra("partyid", partyid);
                startActivity(intent);
            }
        });



    }
}