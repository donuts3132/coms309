package com.example.chainattacker;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.drafts.Draft;
import org.java_websocket.drafts.Draft_6455;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;
import java.net.URISyntaxException;

public class Chat extends AppCompatActivity {

    Button send, back;
    EditText messagee;
    TextView chatlog;

    String username;
    int id;
    int partyid;
    int leaderboardid;
    int userlevel;
    private WebSocketClient cc;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        send = findViewById(R.id.send);
        back = findViewById(R.id.back);
        messagee = findViewById(R.id.message);
        chatlog = findViewById(R.id.chatlog);
        chatlog.setMovementMethod(new ScrollingMovementMethod());
        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        leaderboardid = intent.getIntExtra("leaderboardid", -1);
        id = intent.getIntExtra("id", -1);
        partyid = intent.getIntExtra("partyid", -1);
        userlevel = intent.getIntExtra("userlevel", 1);


        Draft[] drafts = { new Draft_6455()};

        String w = "ws://coms-309-058.class.las.iastate.edu:8080/chat/" + username;

        try {
            cc = new WebSocketClient(new URI(w), (Draft) drafts[0]) {
                @Override
                public void onOpen(ServerHandshake handshakedata) {
                    Log.d("OPEN", "run() returned: " + "is connecting");
                }

                @Override
                public void onMessage(String message) {
                    String s = chatlog.getText().toString();
                    chatlog.setText(s + "\n" + message);
                }

                @Override
                public void onClose(int code, String reason, boolean remote) {
                    Log.d("CLOSE", "onClose() returned: " + reason);
                }

                @Override
                public void onError(Exception ex) {
                    Log.d("Exception:", ex.toString());
                }
            };

        }
        catch (URISyntaxException e){
            e.printStackTrace();
        }
        cc.connect();

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    cc.send(messagee.getText().toString());
                    messagee.setText("");
                }
                catch (Exception e) {
                    Log.d("ExceptionSendMessage:", e.toString());
                }
            }
        });

        back.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Chat.this, MainActivity.class);
                intent.putExtra("username", username);
                intent.putExtra("id", id);
                intent.putExtra("partyid", partyid);
                intent.putExtra("leaderboardid", leaderboardid);
                intent.putExtra("userlevel", userlevel);
                startActivity(intent);
            }
        });
    }
}