package com.example.chainattacker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class AdminSettings extends AppCompatActivity {
    String username;
    int id;
    int leaderboardid;
    int userlevel;
    int partyid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_settings);

        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        id = intent.getIntExtra("id", -1);
        leaderboardid = intent.getIntExtra("leaderboardid", -1);
        userlevel = intent.getIntExtra("userlevel", 1);
        partyid = intent.getIntExtra("partyid", -1);

        Button back = (Button) findViewById(R.id.backAS);
        Button promote = (Button) findViewById(R.id.promote);
        Button updateLeaderboard = (Button) findViewById(R.id.updateLeader);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminSettings.this, Settings.class);

                intent.putExtra("username", username);
                intent.putExtra("id", id);
                intent.putExtra("leaderboardid", leaderboardid);
                intent.putExtra("userlevel", userlevel);
                intent.putExtra("partyid", partyid);
                startActivity(intent);
            }
        });

        promote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminSettings.this, Select.class);

                intent.putExtra("username", username);
                intent.putExtra("id", id);
                intent.putExtra("leaderboardid", leaderboardid);
                intent.putExtra("userlevel", userlevel);
                intent.putExtra("whereto", 1);
                intent.putExtra("partyid", partyid);
                startActivity(intent);
            }
        });

        updateLeaderboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminSettings.this, Select.class);

                intent.putExtra("username", username);
                intent.putExtra("id", id);
                intent.putExtra("leaderboardid", leaderboardid);
                intent.putExtra("userlevel", userlevel);
                intent.putExtra("whereto", 2);
                intent.putExtra("partyid", partyid);
                startActivity(intent);
            }
        });
    }
}