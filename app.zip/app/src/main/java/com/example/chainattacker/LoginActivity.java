package com.example.chainattacker;

import static com.android.volley.toolbox.Volley.newRequestQueue;

import static java.lang.Integer.parseInt;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class LoginActivity extends AppCompatActivity {
    public static int i;
    EditText etUser;
    EditText etPass;

    Button register;
    Button login;

    String userstr;
    String passstr;

    int id;
    int leaderboardid;
    String username;
    JSONObject a;
    int userlevel;

    int counter = 0;

    JSONArray charsInit = new JSONArray();

    JSONArray InitUC = new JSONArray();
    JSONObject newPlayer = new JSONObject();
    int partyid;
    RequestQueue queue;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        login = (Button) findViewById(R.id.login);
        etUser = findViewById(R.id.Username);
        etPass = findViewById(R.id.Password);
        register = findViewById(R.id.regis);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (etUser.getText().toString().isEmpty() || etPass.getText().toString().isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please put text in both fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                userstr = etUser.getText().toString();
                passstr = etPass.getText().toString();
                loggingin();

//                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
//                startActivity(intent);
            }
        });
//        main.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(LoginActivity.this, MainActivity.class));
//            }
//        });
        register.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (etUser.getText().toString().isEmpty() || etPass.getText().toString().isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please put text in both fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                userstr = etUser.getText().toString();
                passstr = etPass.getText().toString();
                registerin();


            }
        });
    }


    private void registerin() {

        queue = newRequestQueue(LoginActivity.this);

        JSONObject respObj;
        respObj = new JSONObject();
        try {
            respObj.put("name", userstr);
            respObj.put("password", passstr);
            respObj.put("userLevel", 1);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        a = new JSONObject();
        try {
            a.put("maxchain", 0);
            a.put("mostbattlesWon", 0);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest r = new JsonObjectRequest(Request.Method.POST, "http://coms-309-058.class.las.iastate.edu:8080/newLeaderboard", a,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse (JSONObject response) {


                        try {
                            a = response;
                            leaderboardid = Integer.parseInt(response.get("boardId").toString());
                            registerChar();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(LoginActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                error.printStackTrace();

            }
        });

        JsonObjectRequest requesto = new JsonObjectRequest(Request.Method.POST, "http://coms-309-058.class.las.iastate.edu:8080/newPlayer", respObj,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse (JSONObject response) {


                        Toast.makeText(LoginActivity.this, "Welcome Aboard, " + userstr, Toast.LENGTH_SHORT).show();


                        try {
                            username = response.get("name").toString();
                            id = response.getInt("id");
                            userlevel = response.getInt("userLevel");
                            newPlayer = response;
                            queue.add(r);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(LoginActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                error.printStackTrace();

            }
        });
        queue.add(requesto);


    }

    private void loggingin() {

        queue = Volley.newRequestQueue(LoginActivity.this);

        JSONObject respObj;

        respObj = new JSONObject();

        String userfetch;
        String passfetch;

        try {
            respObj.put("name", userstr);
            respObj.put("password", passstr);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest requesto = new JsonObjectRequest(Request.Method.POST, "http://coms-309-058.class.las.iastate.edu:8080/login", respObj,

                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse (JSONObject response) {

                        Toast.makeText(LoginActivity.this, "Welcome Back, " + userstr, Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);

                        try {
                            intent.putExtra("username", response.get("name").toString());
                            intent.putExtra("id", Integer.parseInt(response.get("id").toString()));
                            JSONObject r = (JSONObject) response.get("leaderboard");
                            intent.putExtra("leaderboardid", Integer.parseInt(r.get("boardId").toString()));
                            intent.putExtra("userlevel", response.getInt("userLevel"));
                            JSONObject z = response.getJSONObject("party");
                            intent.putExtra("partyid", Integer.parseInt(z.get("id").toString()));
                            startActivity(intent);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

//                Toast.makeText(LoginActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                error.printStackTrace();
                Toast.makeText(LoginActivity.this, "Incorrect username or password", Toast.LENGTH_LONG).show();

            }

        }

        ) {
            @Override
            protected Map<String, String> getParams() {
                // below line we are creating a map for
                // storing our values in key and value pair.
                Map<String, String> params = new HashMap<String, String>();

                // on below line we are passing our key
                // and value pair to our parameters.
                params.put("name", userstr);
                params.put("password", passstr);

                // at last we are
                // returning our params.
                return params;
            }
        };


        queue.add(requesto);
    }

    /**
     * method to select all characters from the rank
     */
    private void registerChar() {
        queue = Volley.newRequestQueue(LoginActivity.this);
        String url = "http://coms-309-058.class.las.iastate.edu:8080/getAllCharacters";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject y = (JSONObject) response.get(i);
                        if (y.getInt("rank") == 0) {
                            charsInit.put(y);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
                generateUserChar();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        queue.add(jsonArrayRequest);

    }

    /**
     * method to generate a userChar
     */
    private void generateUserChar () {
        Random rand = new Random();
        int j = rand.nextInt(charsInit.length());
        JSONObject resp = new JSONObject();

        try {
            JSONObject l = charsInit.getJSONObject(j);
            charsInit.remove(j);
            resp.put("name", l.getString("name"));
            resp.put("health", l.getInt("health"));
            resp.put("attack", l.getInt("attack"));
            resp.put("defense", l.getInt("defense"));
            resp.put("ap", l.getInt("ap"));
            resp.put("level", 1);
            resp.put("xp", 0);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        //need to get leaderboard entry here
        JsonObjectRequest generate = new JsonObjectRequest(Request.Method.POST, "http://coms-309-058.class.las.iastate.edu:8080/newUsersCharacter", resp,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse (JSONObject response) {
                        JSONObject a = response;
                        InitUC.put(a);
                        try {
                            int x = response.getInt("id");
                            connectUCtoP(x);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                error.printStackTrace();

            }
        });
        queue.add(generate);
    }

    /**
     * method to link all the UsersCharacter to the User
     * @param i
     */
    private void connectUCtoP (int i) {

        //need to get leaderboard entry here
        StringRequest UCtoP = new StringRequest(Request.Method.PUT, "http://coms-309-058.class.las.iastate.edu:8080/Players/" + id + "/UsersCharacter/" + i,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse (String response) {
                        String s = response;
                        counter++;
                        if (counter <= 5) {
                            generateUserChar();
                        }
                        else {
                            newParty();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                error.printStackTrace();

            }
        });
        queue.add(UCtoP);
    }

    /**
     * method to generate a new party
     */
    private void newParty () {
        JSONObject resp = new JSONObject();
        try {
            resp.put("player", null);
            resp.put("characters", InitUC);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        //need to get leaderboard entry here
        JsonObjectRequest newParty = new JsonObjectRequest(Request.Method.POST, "http://coms-309-058.class.las.iastate.edu:8080/newParty", resp,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse (JSONObject response) {
                        try {
                            partyid = response.getInt("id");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        linkPlaytoParty();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                error.printStackTrace();

            }
        });
        queue.add(newParty);
    }

    /**
     * method to link a user to the party
     */
    private void linkPlaytoParty (){
        String url = "http://coms-309-058.class.las.iastate.edu:8080/PartyToUser/" + id + "/" + partyid;
        //need to get leaderboard entry here
        StringRequest request = new StringRequest(Request.Method.PUT, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse (String response) {
                        String s = response;
                        boardtoUser();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                error.printStackTrace();

            }
        });
        queue.add(request);
    }

    private void boardtoUser() {
        String url = "http://coms-309-058.class.las.iastate.edu:8080/boardToUser/" + id + "/" + leaderboardid;
        JsonObjectRequest x = new JsonObjectRequest(Request.Method.PUT, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse (JSONObject response) {
                        JSONObject s = response;
                        fillParty();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(LoginActivity.this, error.toString(), Toast.LENGTH_LONG).show();

                error.printStackTrace();

            }
        });
        queue.add(x);
    }

    private void fillParty() {
        JSONObject resp = new JSONObject();
        int[] charsId = new int[6];
        for (int z = 0; z < 6; z++) {
            try {
                JSONObject y = InitUC.getJSONObject(z);
                charsId[z] = y.getInt("id");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        String url = "http://coms-309-058.class.las.iastate.edu:8080/partyMaker/" + partyid + "/" + charsId[0] + "/" + charsId[1] + "/" + charsId[2] + "/" + charsId[3] + "/" + charsId[4] + "/" + charsId[5];
        JsonObjectRequest x = new JsonObjectRequest(Request.Method.POST, url, resp,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse (JSONObject response) {
                        JSONObject s = response;
                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        intent.putExtra("username", username);
                        intent.putExtra("id", id);
                        intent.putExtra("leaderboardid", leaderboardid);
                        intent.putExtra("userlevel", userlevel);
                        intent.putExtra("partyid", partyid);
                        startActivity(intent);

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(LoginActivity.this, error.toString(), Toast.LENGTH_LONG).show();

                error.printStackTrace();

            }
        });
        queue.add(x);

    }

}
