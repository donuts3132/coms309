package com.example.chainattacker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class DeleteCharacter extends AppCompatActivity {
    String username;
    int id;
    int leaderboardid;
    int userlevel;
    int Cid;
    int partyid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_character);

        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        id = intent.getIntExtra("id", -1);
        leaderboardid = intent.getIntExtra("leaderboardid", -1);
        userlevel = intent.getIntExtra("userlevel", 1);
        Cid = intent.getIntExtra("Cid", -1);
        partyid = intent.getIntExtra("partyid", -1);

        Button back = (Button) findViewById(R.id.ContinueC);
        Button SNC = (Button) findViewById(R.id.SNC);
        Button DC = (Button) findViewById(R.id.DeleteC);

        updateDisplay();


        DC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RequestQueue queue = Volley.newRequestQueue(DeleteCharacter.this);
                StringRequest requesto = new StringRequest(Request.Method.DELETE, "http://coms-309-058.class.las.iastate.edu:8080/deleteChar/" + Cid,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse (String response) {
                                Toast.makeText(DeleteCharacter.this, "Successfully Deleted", Toast.LENGTH_SHORT).show();
                                Intent intent1 = new Intent(DeleteCharacter.this, TesterSettings.class);
                                intent1.putExtra("username", username);
                                intent1.putExtra("id", id);
                                intent1.putExtra("leaderboardid", leaderboardid);
                                intent1.putExtra("userlevel", userlevel);
                                intent1.putExtra("partyid", partyid);
                                startActivity(intent1);
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(DeleteCharacter.this, "Failed Delete", Toast.LENGTH_SHORT).show();
                        error.printStackTrace();

                    }
                });
                queue.add(requesto);
            }
        });

        SNC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(DeleteCharacter.this, SelectMonster.class);
                intent1.putExtra("username", username);
                intent1.putExtra("id", id);
                intent1.putExtra("leaderboardid", leaderboardid);
                intent1.putExtra("userlevel", userlevel);
                intent1.putExtra("partyid", partyid);
                intent1.putExtra("whereto", 0);
                startActivity(intent1);
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(DeleteCharacter.this, TesterSettings.class);
                intent1.putExtra("username", username);
                intent1.putExtra("id", id);
                intent1.putExtra("leaderboardid", leaderboardid);
                intent1.putExtra("userlevel", userlevel);
                intent1.putExtra("partyid", partyid);
                startActivity(intent1);
            }
        });
    }
    private void updateDisplay() {
        TextView display = (TextView) findViewById(R.id.CMDisplay);
        TextView currentl = (TextView) findViewById(R.id.currentCdisplay);
        RequestQueue queue = Volley.newRequestQueue(DeleteCharacter.this);

        //need to get leaderboard entry here
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, "http://coms-309-058.class.las.iastate.edu:8080/Character/" + Cid, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        JSONObject a = response;
                        try {
                            display.setText("Stats of " + response.getString("name") + ":");
                            String z = response.get("health").toString();
                            String y = response.get("attack").toString();
                            String x = response.get("defense").toString();
                            String w = response.get("ap").toString();
                            String v = response.get("rank").toString();
                            currentl.setText("Health: " + z + "\nAttack: " + y + "\nDefense: " + x + "\nAP Cost: " + w + "\nRank Range: " + v);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                error.printStackTrace();

            }
        });
        queue.add(request);
    }
}