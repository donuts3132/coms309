package com.example.chainattacker;

import static com.android.volley.toolbox.Volley.newRequestQueue;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

/**
 * The screen where you can assign party members to the party. 
 */
public class PartyActivity extends AppCompatActivity {

    /**
     * Refers to the button that adds Orange to the party.
     */
    Button orange;
    /**
     * Refers to the button that adds Book to the party.
     */
    Button book;
    /**
     * Refers to the button that adds Brush to the party.
     */
    Button brush;
    /**
     * Refers to the button that adds Cat to the party.
     */
    Button cat;
    /**
     * Refers to the button that adds Owl to the party.
     */
    Button owl;
    /**
     * Refers to the button that adds Rambutan to the party.
     */
    Button rambu;
    /**
     * Refers to the image view that shows the first party member.
     */
    TextView party1;
    /**
     * Refers to the image view that shows the second party member.
     */
    TextView party2;
    /**
     * Refers to the image view that shows the third party member.
     */
    TextView party3;
    /**
     * Refers to the image view that shows the fourth party member.
     */
    TextView party4;
    /**
     * Refers to the image view that shows the fifth party member.
     */
    TextView party5;
    /**
     * Refers to the image view that shows the sixth party member.
     */
    TextView party6;

    /**
     * Refers to the button that goes back to the main screen.
     */
    Button back;

    /**
     * Refers to the button that resets party lineup.
     */
    Button reset;
    /**
     * Refers to the button that undoes character selection from the party.
     */
    Button undo;

    /**
     * Refers to the array of party units fetched from the server.
     */
    JSONArray party = new JSONArray();

    /**
     * Refers to the array of party units used to create the party.
     */
    JSONArray currparty = new JSONArray();

    /**
     * Refers to the array of strings that is made of the user's available characters.
     */
    ArrayList<String> partyarray;

    /**
     * the id of the current logged on user's leaderboard
     */
    int leaderboardid;
    /**
     * the id of the current logged on user
     */
    int id;
    /**
     * the username of the current logged on user
     */
    String username;
    /**
     * the current max chain of the current logged on user
     */
    int maxchain;
    /**
     * the current battles won of the current user
     */
    int battlesWon;
    int partyid;
    int userlevel;
    RequestQueue queue;
    ArrayAdapter adapter;


    /**
     * Creates the party screen. Players can add characters to the party that will be used to in the
     * battles. For now, each button represents a character unit that can be added to the party; press on a
     * character, and it will be added to the party array.
     * @param savedInstanceState
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        id = intent.getIntExtra("id", -1);
        partyid = intent.getIntExtra("partyid", -1);
        leaderboardid = intent.getIntExtra("leaderboardid", -1);
        userlevel = intent.getIntExtra("userlevel", 1);

        queue = Volley.newRequestQueue(PartyActivity.this);
        Context context = this;
        
        final Handler handler = new Handler();

        new Thread() {
            public void run() {
                getPartyMemb();

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        Log.d("party", "making list");
                        adapter = new ArrayAdapter<String>(context,
                                R.layout.activity_listview, partyarray);

                        ListView listView = (ListView) findViewById(R.id.party_list);
                        listView.setAdapter(adapter);

                        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){

                            @Override
                            public void onItemClick(AdapterView<?> adapterView, View view, int posi, long id) {

                                boolean dupeCheck = true;

                                for (int i = 0; i < currparty.length(); i++) {

                                    try {
                                        Object temp = party.get(posi);
                                        if (temp.equals(currparty.get(i))) {

                                            dupeCheck = false;
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }

                                if (dupeCheck) {

                                    if (party1.getText().toString() == "Empty") {

                                        party1.setText(partyarray.get(posi));
                                    }
                                    else if (party2.getText().toString() == "Empty") {

                                        party2.setText(partyarray.get(posi));
                                    }
                                    else if (party3.getText().toString() == "Empty") {

                                        party3.setText(partyarray.get(posi));
                                    }
                                    else if (party4.getText().toString() == "Empty") {

                                        party4.setText(partyarray.get(posi));
                                    }
                                    else if (party5.getText().toString() == "Empty") {

                                        party5.setText(partyarray.get(posi));
                                    }
                                    else if (party6.getText().toString() == "Empty") {

                                        party6.setText(partyarray.get(posi));
                                    }

                                    try {
                                        currparty.put(party.get(posi));
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        });
                    }
                }, 300);
            }

        }.start();

        setContentView(R.layout.activity_party);

//        orange = findViewById(R.id.orange);
//        book = findViewById(R.id.book);
//        brush = findViewById(R.id.hair);
//        cat = findViewById(R.id.cat);
//        owl = findViewById(R.id.owl);
//        rambu = findViewById(R.id.rambu);
        party1 = findViewById(R.id.porty1);
        party2 = findViewById(R.id.porty2);
        party3 = findViewById(R.id.porty3);
        party4 = findViewById(R.id.porty4);
        party5 = findViewById(R.id.porty5);
        party6 = findViewById(R.id.porty6);

        party1.setText("Empty");
        party2.setText("Empty");
        party3.setText("Empty");
        party4.setText("Empty");
        party5.setText("Empty");
        party6.setText("Empty");

        queue = Volley.newRequestQueue(PartyActivity.this);


//        if (partyarray.size() < 1){
//
//            Log.d("party test", "Party empty");
//
////            partyarray.add("abc");
////            partyarray.add("def");
////            partyarray.add("ghi");
//        }

        back = findViewById(R.id.back);
        reset = findViewById(R.id.reset);
        undo = findViewById(R.id.undo);

        back.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if (party6.getText() != "Empty") {
//                    Toast.makeText(PartyActivity.this, "Party must be full", Toast.LENGTH_LONG).show();
//                    Intent intent = new Intent(PartyActivity.this, MainActivity.class);
//                    intent.putExtra("username", username);
//                    intent.putExtra("id", id);
//                    intent.putExtra("leaderboardid", leaderboardid);
//                    intent.putExtra("partyid", partyid);
//                    intent.putExtra("userlevel", userlevel);
//                    startActivity(intent);
//                    return;
                        UpdateParty();
                }
                else {
                    Toast.makeText(PartyActivity.this, "Must Have Full Party To Save", Toast.LENGTH_LONG).show();
                }

                Intent intent = new Intent(PartyActivity.this, MainActivity.class);
                intent.putExtra("username", username);
                intent.putExtra("id", id);
                intent.putExtra("leaderboardid", leaderboardid);
                intent.putExtra("partyid", partyid);
                intent.putExtra("userlevel", userlevel);
                startActivity(intent);
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                party1.setText("Empty");
                party2.setText("Empty");
                party3.setText("Empty");
                party4.setText("Empty");
                party5.setText("Empty");
                party6.setText("Empty");

                for (int i = 5; i >= 0; i--) {

                    try {
                        if (currparty.get(i) != null) {
                            currparty.remove(i);

                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        undo.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if (party6.getText().toString() != "Empty") {

                    party6.setText("Empty");
                    currparty.remove(5);
                }
                else if (party5.getText().toString() != "Empty") {

                    party5.setText("Empty");
                    currparty.remove(4);
                }
                else if (party4.getText().toString() != "Empty") {

                    party4.setText("Empty");
                    currparty.remove(3);
                }
                else if (party3.getText().toString() != "Empty") {

                    party3.setText("Empty");
                    currparty.remove(2);
                }
                else if (party2.getText().toString() != "Empty") {

                    party2.setText("Empty");
                    currparty.remove(1);
                }
                else if (party1.getText().toString() != "Empty") {

                    party1.setText("Empty");
                    currparty.remove(0);
                }
            }
        });

        Log.d("party", "finished end");
//
//        orange.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View view) {
//                orange.setSelected(!orange.isPressed());
//
//                if (orange.isPressed()) {
//
//                    FillMember(1);
//
//                }
//            }
//        });
//
//        book.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View view) {
//                book.setSelected(!book.isPressed());
//
//                if (book.isPressed()) {
//
//                    FillMember(2);
//
//                }
//            }
//        });
//
//        brush.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View view) {
//                brush.setSelected(!brush.isPressed());
//
//                if (brush.isPressed()) {
//
//                    FillMember(3);
//
//                }
//            }
//        });
//
//        cat.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View view) {
//                cat.setSelected(!cat.isPressed());
//
//                if (cat.isPressed()) {
//
//                    FillMember(4);
//
//                }
//            }
//        });
//
//        owl.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View view) {
//                owl.setSelected(!owl.isPressed());
//
//                if (owl.isPressed()) {
//
//                    FillMember(5);
//
//                }
//            }
//        });
//
//        rambu.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View view) {
//                rambu.setSelected(!rambu.isPressed());
//
//                if (rambu.isPressed()) {
//
//                    FillMember(6);
//
//                }
//            }
//        });

    }

//    @Override
//            protected void onResume() {
//
//        super.onResume();
//        Log.d("party", "resume");
//        adapter.notifyDataSetChanged();
//    }

//    /**
//     * Adds units to the party. The method takes in an ID number depending on which character you pressed on,
//     * then adds the character to the earliest unfilled spot on the array.
//     * @param id
//     */

//    void FillMember(int id) {
//
//        for (int i = 0; i < 6; i++) {
//
//            if(party[i] == null) {
//
//                if (id == 1) {
////                    party[i] = new Orange();
//                    FillSlot(i, id);
//                    return;
//
//                }
//                else if (id == 2) {
////                    party[i] = new Book();
//                    FillSlot(i, id);
//                    return;
//                }
//                else if (id == 3) {
////                    party[i] = new Hairbrush();
//                    FillSlot(i, id);
//                    return;
//                }
//                else if (id == 4) {
////                    party[i] = new Cat();
//                    FillSlot(i, id);
//                    return;
//                }
//                else if (id == 5) {
////                    party[i] = new Owl();
//                    FillSlot(i, id);
//                    return;
//                }
//                else if (id == 6) {
////                    party[i] = new Rambutan();
//                    FillSlot(i, id);
//                    return;
//                }
//
//            }
//        }
//
//
//    }

//    /**
//     * Fills the party graphic above. Takes in slot (party position) and idnumb (party member) and fills the respective slot.
//     * @param slot
//     * @param idnumb
//     */

//    void FillSlot(int slot, int idnumb) {
//
//        int temp;
//
//        if (idnumb == 1) {
//
//            temp = R.drawable.ornag;
//        }
//        else if (idnumb == 2) {
//
//            temp = R.drawable.book;
//        }
//        else if (idnumb == 3) {
//
//            temp = R.drawable.broosh;
//        }
//        else if (idnumb == 4) {
//
//            temp = R.drawable.kott;
//        }
//        else if (idnumb == 5) {
//
//            temp = R.drawable.owl;
//        }
//        else {
//
//            temp = R.drawable.ramtan;
//        }
//
//        if (slot == 0) {
//
//            party1.setImageResource(temp);
//        }
//        else if (slot == 1) {
//
//            party2.setImageResource(temp);
//        }
//        else if (slot == 2) {
//
//            party3.setImageResource(temp);
//        }
//        else if (slot == 3) {
//
//            party4.setImageResource(temp);
//        }
//        else if (slot == 4) {
//
//            party5.setImageResource(temp);
//        }
//        else {
//
//            party6.setImageResource(temp);
//        }
//    }

    void getPartyMemb() {


        partyarray = new ArrayList<String>();

        JsonArrayRequest respt = new JsonArrayRequest(Request.Method.GET, "http://coms-309-058.class.las.iastate.edu:8080/player/userCharacters/" + id,
                null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response){

                        if (response != null) {

                            Log.d("party test", "Accessed response");

                            for (int i = 0; i < response.length(); i++) {

                                try {
                                    Log.d("party test", "getting char #" + i);
                                    JSONObject temp = response.getJSONObject(i);
                                    party.put(temp);
                                    String tempo = temp.getString("name") + ": " + temp.getInt("attack") + "atk, " + temp.getInt("defense") + "def"; //name: 12atk, 12def
                                    partyarray.add(tempo);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                        else {

                            Log.d("party test", "Response empty");

                            partyarray.add("abc");
                            partyarray.add("def");
                            partyarray.add("ghi");
                        }

                    }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                error.printStackTrace();
                Log.d("party test", "Error response");
                partyarray.add("abc");
                partyarray.add("def");
                partyarray.add("ghi");
            }


        });

        queue.add(respt);
    }

    /**
     * Uploads the party to the server to be used in battle.
     */
    void UpdateParty() {

        String party = Integer.toString(partyid) + "/";


        for (int i = 0; i < 5; i++) {

            try {
                JSONObject charac = currparty.getJSONObject(i);
                party = party + charac.getInt("id") + "/";
            }
            catch (JSONException e){
                e.printStackTrace();
            }
        }

        try {
            JSONObject charac = currparty.getJSONObject(5);
            party = party + charac.getInt("id");
        }
        catch (JSONException e){
            e.printStackTrace();
        }

        JsonObjectRequest requesto = new JsonObjectRequest(Request.Method.POST, "http://coms-309-058.class.las.iastate.edu:8080/partyMaker/" + party, null,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse (JSONObject response) {

                        //continue as normal
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(PartyActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                        error.printStackTrace();

                    }
        });

        queue.add(requesto);
    }


}


