package com.example.chainattacker;

import static java.lang.Integer.parseInt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    String username;
    int id;
    int battlesWon;
    int maxchain;
    int leaderboardid;
    int userlevel;
    int partyid;
    RequestQueue queue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        id = intent.getIntExtra("id", -1);
        leaderboardid = intent.getIntExtra("leaderboardid", -1);
        userlevel = intent.getIntExtra("userlevel", 1);
        partyid = intent.getIntExtra("partyid", -1);


        TextView user = (TextView) findViewById(R.id.username);
        TextView iddisplay = (TextView) findViewById(R.id.id);
        TextView BW = (TextView) findViewById(R.id.BattlesWon);
        TextView MC = (TextView) findViewById(R.id.MaxChain);
        Button button = (Button) findViewById(R.id.leaderboard);
        Button battle = (Button) findViewById(R.id.battlebutton);
        Button party = (Button) findViewById(R.id.partybtn);
        Button settings = (Button) findViewById(R.id.Settings);
        Button chat = (Button) findViewById(R.id.chat);

        user.setText(username);
        iddisplay.setText("" + id);




        battle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, BattleSelect.class);
                intent.putExtra("name", username);
                intent.putExtra("id", id);
                intent.putExtra("BattlesWon", battlesWon);
                intent.putExtra("Maxchain", maxchain);
                intent.putExtra("leaderboardid", leaderboardid);
                intent.putExtra("userlevel", userlevel);
                intent.putExtra("partyid", partyid);
                startActivity(intent);
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Leaderboard.class);
                intent.putExtra("username", username);
                intent.putExtra("id", id);
                intent.putExtra("leaderboardid", leaderboardid);
                intent.putExtra("userlevel", userlevel);
                intent.putExtra("partyid", partyid);
                startActivity(intent);
            }
        });


        party.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(MainActivity.this, PartyActivity.class);
                intent1.putExtra("username", username);
                intent1.putExtra("id", id);
                intent1.putExtra("leaderboardid", leaderboardid);
                intent1.putExtra("userlevel", userlevel);
                intent1.putExtra("partyid", partyid);
                startActivity(intent1);
            }
        });

        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(MainActivity.this, Settings.class);
                intent1.putExtra("username", username);
                intent1.putExtra("id", id);
                intent1.putExtra("leaderboardid", leaderboardid);
                intent1.putExtra("userlevel", userlevel);
                intent1.putExtra("partyid", partyid);
                startActivity(intent1);
            }
        });

        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(MainActivity.this, Chat.class);
                intent1.putExtra("username", username);
                intent1.putExtra("id", id);
                intent1.putExtra("leaderboardid", leaderboardid);
                intent1.putExtra("userlevel", userlevel);
                intent1.putExtra("partyid", partyid);
                startActivity(intent1);
            }
        });


    }
    @Override
    protected void onStart() {
        super.onStart();
        TextView BW = (TextView) findViewById(R.id.BattlesWon);
        TextView MC = (TextView) findViewById(R.id.MaxChain);
        queue = Volley.newRequestQueue(MainActivity.this);
        //need to get leaderboard entry here
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, "http://coms-309-058.class.las.iastate.edu:8080/leaderboard/" + leaderboardid, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse (JSONObject response) {
                        JSONObject a = response;
                        try{
                            String y = response.get("mostbattlesWon").toString();
                            String z = response.get("maxchain").toString();
                            battlesWon = parseInt(y);
                            maxchain = parseInt(z);
                            BW.setText(y);
                            MC.setText(z);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                error.printStackTrace();

            }
        });
        queue.add(request);
    }

}