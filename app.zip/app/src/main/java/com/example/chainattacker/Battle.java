package com.example.chainattacker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;
import java.util.Random;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Screen that handles the battle display and logic
 */
public class Battle extends AppCompatActivity {
    //need monster and party info
    /**
     * username of current logged on user
     */
    String username;
    /**
     * id of current logged on user
     */
    int id;
    /**
     * highest chain all time of current logged on user
     */
    int Maxchain;
    /**
     * count of battles won by current logged on user
     */
    int BattlesWon;
    /**
     * leaderboard id of current logged on user
     */
    int leaderboardid;
    /**
     * instance of random to be used to generate new AP added
     */
    Random rand = new Random();
    /**
     * current chain counter
     */
    int counter = 0;
    /**
     * highest chain of this battle
     */
    int chain = 0;
    /**
     * the monsters current health
     */
    int mHealth;
    /**
     * the monster's original health
     */
    int oHealth;
    /**
     * Current AP of the user
     */
    int AP = rand.nextInt(5) + 8;
    /**
     * The attack of the monster
     */
    int mAttack = 5;
    /**
     * array of all character's attacks
     */
    int[] cattack = new int[6];
    /**
     * array of all characters
     */
    int[] cHP = new int[6];
    /**
     * array of all characters ap
     */
    int[] cap = new int[6];
    /**
     * name of the monster
     */
    String mName;
    /**
     * array of all characters defense
     */
    int[] cDefense = new int[6];
    /**
     * the permissions of the user
     */
    int userlevel;
    /**
     * the array of characters alive or dead
     */
    int[] charalive = new int[6];
    /**
     * the array of current characters health
     */
    int[] chpcurr = new int[6];
    /**
     * monster defense
     */
    int mDefense;
    /**
     * gain of xp from the monster
     */
    int xpgain;

    double multiplier = 1.00;
    int mRank;


    int[] buttons = new int[6];

    String[] charNames = new String[6];
    int[] charLevel = new int[6];
    int partyid;
    int[] charId = new int[6];


    /**
     * Creates the display of the battle for the current logged on user, This involves 7 buttons one for
     * attacking with each character and one to end one's current turn, When the user ends their turn depending
     * on the amount of AP the user has left a random set of numbers will be generated to determine which characters
     * will return to the party, If the amount of AP is 0 then the chain continues and the player gets all characters
     * back, If AP is not 0 at the end of a turn, the monster will attack.
     * @author Derek Lengemann
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_battle);

        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        id = intent.getIntExtra("id", -1);
        Maxchain = intent.getIntExtra("Maxchain", -1);
        BattlesWon = intent.getIntExtra("BattlesWon", -1);
        mHealth = intent.getIntExtra("mHealth", 0);
        mAttack = intent.getIntExtra("mAttack", 0);
        leaderboardid = intent.getIntExtra("leaderboardid", -1);
        mName = intent.getStringExtra("mName");
        userlevel = intent.getIntExtra("userlevel", -1);
        mDefense = intent.getIntExtra("mDefense", -1);
        xpgain = intent.getIntExtra("xpgain", -1);
        mRank = intent.getIntExtra("mRank", 0);
        partyid = intent.getIntExtra("partyid", -1);

        TextView m = (TextView) findViewById(R.id.mName);
        TextView maxc = (TextView) findViewById(R.id.biggestchain);
        TextView curr = (TextView) findViewById(R.id.currentchain);
        Button end = (Button) findViewById(R.id.endturn);
        Button exit = (Button) findViewById(R.id.exit);
        TextView dmg = (TextView) findViewById(R.id.textView9);
        dmg.setText("Damage Multiplier: x" + multiplier);

        Button c1 = (Button) findViewById(R.id.c1);
        Button c3 = (Button) findViewById(R.id.c3);
        Button c5 = (Button) findViewById(R.id.c5);
        Button c2 = (Button) findViewById(R.id.c2);
        Button c4 = (Button) findViewById(R.id.c4);
        Button c6 = (Button) findViewById(R.id.c6);

        buttons[0] = R.id.c1;
        buttons[1] = R.id.c2;
        buttons[2] = R.id.c3;
        buttons[3] = R.id.c4;
        buttons[4] = R.id.c5;
        buttons[5] = R.id.c6;
        //configure monster

        m.setText(mName);


        for (int i = 0; i < 6; i++) {
            charalive[i] = 1;
        }
        oHealth = mHealth;
        RequestQueue queue = Volley.newRequestQueue(Battle.this);
        //configure characters
        JsonObjectRequest requesto = new JsonObjectRequest(Request.Method.GET, "http://coms-309-058.class.las.iastate.edu:8080/getParty/" + partyid, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse (JSONObject response) {
                        JSONArray s = new JSONArray();
                        try {
                            s = response.getJSONArray("characters");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        for (int i = 0; i < 6; i++) {
                            try {
                                JSONObject g = s.getJSONObject(i);
                                charNames[i] = g.getString("name");
                                charLevel[i] = g.getInt("level");
                                cap[i] = g.getInt("ap");
                                cHP[i] = g.getInt("health");
                                cattack[i] = g.getInt("attack");
                                cDefense[i] = g.getInt("defense");
                                chpcurr[i] = cHP[i];
                                charId[i] = g.getInt("id");
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        //set text for everything
                        c1.setText(charNames[0]);
                        c3.setText(charNames[1]);
                        c5.setText(charNames[2]);
                        c2.setText(charNames[3]);
                        c4.setText(charNames[4]);
                        c6.setText(charNames[5]);

                        setDisplay();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


                error.printStackTrace();

            }
        });

        queue.add(requesto);



        //configure the button presses
        c1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (AP - cap[0] >= 0) {
                    playerTurn(0);
                    c1.setEnabled(false);
                }
            }
        });
        c3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (AP - cap[1] >= 0) {
                    playerTurn(1);
                    c3.setEnabled(false);
                }
            }
        });
        c5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (AP - cap[2] >= 0) {
                    playerTurn(2);
                    c5.setEnabled(false);
                }
            }
        });
        c2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (AP - cap[3] >= 0) {
                    playerTurn(3);
                    c2.setEnabled(false);
                }
            }
        });
        c4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (AP -cap[4] >= 0) {
                    playerTurn(4);
                    c4.setEnabled(false);
                }
            }
        });
        c6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (AP - cap[5] >= 0) {
                    playerTurn(5);
                    c6.setEnabled(false);
                }
            }
        });
        //configure the end turn
        end.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random rand = new Random();
                int total = 0;
                if (AP == 0) {
                    for (int i = 0; i < 6; i++) {

                        if (charalive[i] == 1) {
                            total = total + cap[i];
                            Button a = (Button) findViewById(buttons[i]);
                            a.setEnabled(true);
                        }
                    }
                    int carryover = AP;
                    if (total > 10) {
                        AP = rand.nextInt(total - 9) + 10;
                    } else {
                        AP = rand.nextInt(total) + 1;
                    }
                    AP = AP + carryover;
                    if (AP + carryover > total) {
                        AP = total;
                    }

                    setDisplay();
                }
                else {
                    monsterAttack();
                    multiplier = 1.00;
                    dmg.setText("Damage Multiplier: x" + multiplier);
                    for (int i = 0; i < 6; i++) {
                        if (charalive[i] == 1) {
                            total = total + cap[i];
                        }
                    }
                    int carryover = AP;
                    if (total > 10) {
                        AP = rand.nextInt(total - 9) + 10;
                    } else {
                        AP = rand.nextInt(total) + 1;
                    }
                    AP = AP + carryover;
                    if (AP + carryover > total) {
                        AP = total;
                    }
                    setDisplay();

                    if (counter > chain) {
                        chain = counter;
                        maxc.setText("" + chain);
                    }
                    counter = 0;
                    curr.setText("" + counter);
                }
            }
        });

        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(Battle.this, MainActivity.class);
                intent1.putExtra("leaderboardid", leaderboardid);
                intent1.putExtra("id", id);
                intent1.putExtra("username", username);
                intent1.putExtra("userlevel", userlevel);
                intent1.putExtra("partyid", partyid);
                startActivity(intent1);
            }
        });


    }

    /**
     * method to switch screens where if i = 1 victory and if i = 0 defeat
     * @author Derek Lengemann
     */
    private void SwitchScreens(int i) {
        if (counter > chain) {
            chain = counter;
        }
        Intent intent1 = new Intent(Battle.this, Rewards.class);
        intent1.putExtra("Result", i);
        intent1.putExtra("CurrChain", chain);
        intent1.putExtra("Maxchain", Maxchain);
        intent1.putExtra("BattlesWon", BattlesWon + i);
        intent1.putExtra("id", id);
        intent1.putExtra("username", username);
        intent1.putExtra("leaderboardid", leaderboardid);
        intent1.putExtra("xpgain", xpgain);
        intent1.putExtra("mRank", mRank);
        intent1.putExtra("userlevel", userlevel);
        intent1.putExtra("charNames", charNames);
        intent1.putExtra("charLevel", charLevel);
        intent1.putExtra("partyid", partyid);
        intent1.putExtra("charId", charId);
        startActivity(intent1);



    }

    private void monsterAttack() {
        int[] buttons = new int[6];
        buttons[0] = R.id.c1;
        buttons[1] = R.id.c2;
        buttons[2] = R.id.c3;
        buttons[3] = R.id.c4;
        buttons[4] = R.id.c5;
        buttons[5] = R.id.c6;
        ArrayList<Integer> mightHit = new ArrayList<>();
        for (int j = 0; j < 6; j++) {
            if (charalive[j] == 1) {
                mightHit.add(j);
            }
        }
        int gotHit = rand.nextInt(mightHit.size());
        monsterDamage(mightHit.get(gotHit));
        Boolean stillalive = false;
        for (int j = 0; j < 6; j++) {
            if (charalive[j] == 1) {
                stillalive = true;
            }
        }
        if (stillalive == false) {
            SwitchScreens(0);
        }
        ArrayList<Integer> charmightsave = new ArrayList<Integer>();
        for (int i = 0; i < 6; i++) {
            Button a = (Button) findViewById(buttons[i]);

            if ((charalive[i] == 1) && a.isEnabled() == false) {
                charmightsave.add(i);
            }

        }
        if (AP < 3) {
            saveCharacters(charmightsave, 2);
        }
        else if (AP < 5) {
            saveCharacters(charmightsave, 3);
        }
        else {
            saveCharacters(charmightsave, 4);
        }

        setDisplay();

        for (int i = 0; i < 6; i++) {
            if (charalive[i] == 0) {
                Button a = (Button) findViewById(buttons[i]);
                a.setVisibility(View.GONE);
            }

        }


    }
    private void monsterDamage(int i) {
        if (charalive[i] == 1) {
            int hit = (mAttack - ((cDefense[i] / 100) * mAttack));
            if (hit == 0) {
                hit = 1;
            }
            chpcurr[i] -= hit;
            if (chpcurr[i] <= 0) {
                chpcurr[i] = 0;
                charalive[i] = 0;
            }
        }
    }
    private void playerTurn(int a) {
        TextView curr = (TextView) findViewById(R.id.currentchain);
        TextView dmg = (TextView) findViewById(R.id.textView9);
        double hit = (cattack[a] - ((mDefense / 100) * cattack[a])) * multiplier;
        if (hit < 1) {
            hit = 1;
        }
        mHealth -= Math.round(hit);
        if (mHealth <= 0) {
            SwitchScreens(1);
        }
        AP -= cap[a];
        multiplierIncrement();
        dmg.setText("Damage Multiplier: x" + multiplier);
        counter++;
        setDisplay();
    }
    private void setDisplay() {
        TextView chp = (TextView) findViewById(R.id.chp);
        TextView chp2 = (TextView) findViewById(R.id.chp2);
        TextView chp3 = (TextView) findViewById(R.id.chp3);
        TextView chp4 = (TextView) findViewById(R.id.chp4);
        TextView chp5 = (TextView) findViewById(R.id.chp5);
        TextView chp6 = (TextView) findViewById(R.id.chp6);
        TextView hp = (TextView) findViewById(R.id.hp);
        TextView ap = (TextView) findViewById(R.id.AP);
        TextView curr = (TextView) findViewById(R.id.currentchain);

        hp.setText("HP: " + mHealth + "/" + oHealth);
        ap.setText("AP: " + AP);
        curr.setText("" + counter);

        chp.setText("HP: " + chpcurr[0] + "/" + cHP[0] + "\nAttack: " + cattack[0] + "\nAP Cost: " + cap[0]);
        chp2.setText("HP: " + chpcurr[1] + "/" + cHP[1] + "\nAttack: " + cattack[1] + "\nAP Cost: " + cap[1]);
        chp3.setText("HP: " + chpcurr[2] + "/" + cHP[2] + "\nAttack: " + cattack[2] + "\nAP Cost: " + cap[2]);
        chp4.setText("HP: " + chpcurr[3] + "/" + cHP[3] + "\nAttack: " + cattack[3] + "\nAP Cost: " + cap[3]);
        chp5.setText("HP: " + chpcurr[4] + "/" + cHP[4] + "\nAttack: " + cattack[4] + "\nAP Cost: " + cap[4]);
        chp6.setText("HP: " + chpcurr[5] + "/" + cHP[5] + "\nAttack: " + cattack[5] + "\nAP Cost: " + cap[5]);
    }

    private void saveCharacters(ArrayList<Integer> j, int CharReturned) {
        ArrayList<Integer> saved = new ArrayList<Integer>();
        while (j.size() != 0 && saved.size() != CharReturned) {
            int previous = rand.nextInt(j.size());
            saved.add(j.get(previous));
            j.remove(previous);
        }
        //gathering the ids of all the buttons of the characters

        buttons[0] = R.id.c1;
        buttons[1] = R.id.c2;
        buttons[2] = R.id.c3;
        buttons[3] = R.id.c4;
        buttons[4] = R.id.c5;
        buttons[5] = R.id.c6;

        //settings all saved buttons back to enabled
        for (int i = 0; i < saved.size(); i++) {
            Button a = (Button) findViewById(buttons[saved.get(i)]);
            a.setEnabled(true);
        }
    }

    private void multiplierIncrement() {
        multiplier = multiplier + 0.05;
        multiplier = Math.round(multiplier * 100.0) / 100.0;
    }

}
