package com.example.chainattacker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Queue;

public class AddMonster extends AppCompatActivity {
    String username;
    int id;
    int leaderboardid;
    int userlevel;
    int partyid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_monster);

        Button backaddm = (Button) findViewById(R.id.backaddm);
        Button addm = (Button) findViewById(R.id.AMbtn);

        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        id = intent.getIntExtra("id", -1);
        leaderboardid = intent.getIntExtra("leaderboardid", -1);
        userlevel = intent.getIntExtra("userlevel", 1);
        partyid = intent.getIntExtra("partyid", -1);


        Spinner dropdown = findViewById(R.id.spinner2);
        String[] items = new String[]{"1", "2", "3"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        dropdown.setAdapter(adapter);

        backaddm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(AddMonster.this, TesterSettings.class);
                intent1.putExtra("username", username);
                intent1.putExtra("id", id);
                intent1.putExtra("leaderboardid", leaderboardid);
                intent1.putExtra("userlevel", userlevel);
                intent1.putExtra("partyid", partyid);
                startActivity(intent1);
            }
        });

        addm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText n = (EditText) findViewById(R.id.editMname);
                EditText h = (EditText) findViewById(R.id.editMHealth);
                EditText a = (EditText) findViewById(R.id.editMAttack);
                EditText d = (EditText) findViewById(R.id.editMDefense);
                EditText xp = (EditText) findViewById(R.id.editMXPgain);

                String name = n.getText().toString();
                int health = Integer.parseInt(h.getText().toString());
                int attack = Integer.parseInt(a.getText().toString());
                int defense = Integer.parseInt(d.getText().toString());
                int xpgain = Integer.parseInt(xp.getText().toString());
                int RR = Integer.parseInt(dropdown.getSelectedItem().toString());

                JSONObject resp = new JSONObject();
                try {
                    resp.put("name", name);
                    resp.put("health", health);
                    resp.put("attack", attack);
                    resp.put("defense", defense);
                    resp.put("xpgain", xpgain);
                    resp.put("rankRange", RR);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                RequestQueue queue = Volley.newRequestQueue(AddMonster.this);

                JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, "http://coms-309-058.class.las.iastate.edu:8080/postMonster", resp,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse (JSONObject response) {
                                n.setText("");
                                h.setText("");
                                a.setText("");
                                d.setText("");
                                xp.setText("");
                                Toast.makeText(AddMonster.this, "Successfully added " + name, Toast.LENGTH_SHORT).show();

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(AddMonster.this, "Failed to add " + name, Toast.LENGTH_SHORT).show();
                        error.printStackTrace();

                    }
                });
                queue.add(request);

            }
        });
    }
}