package com.example.chainattacker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class AddCharacter extends AppCompatActivity {
    String username;
    int id;
    int leaderboardid;
    int userlevel;
    int partyid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_character);

        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        id = intent.getIntExtra("id", -1);
        leaderboardid = intent.getIntExtra("leaderboardid", -1);
        userlevel = intent.getIntExtra("userlevel", 1);
        partyid = intent.getIntExtra("partyid", -1);

        Button backaddc = (Button) findViewById(R.id.backaddc);
        Button addc = (Button) findViewById(R.id.ACbtn);

        Spinner dropdown = findViewById(R.id.spinner3);
        String[] items = new String[]{"0", "1", "2", "3"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        dropdown.setAdapter(adapter);

        backaddc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(AddCharacter.this, TesterSettings.class);
                intent1.putExtra("username", username);
                intent1.putExtra("id", id);
                intent1.putExtra("leaderboardid", leaderboardid);
                intent1.putExtra("userlevel", userlevel);
                intent1.putExtra("partyid", partyid);
                startActivity(intent1);
            }
        });

        addc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText n = (EditText) findViewById(R.id.addcname);
                EditText h = (EditText) findViewById(R.id.addcHealth);
                EditText a = (EditText) findViewById(R.id.addcAttack);
                EditText d = (EditText) findViewById(R.id.addcDefense);
                EditText AP = (EditText) findViewById(R.id.addcAP);

                String name = n.getText().toString();
                int health = Integer.parseInt(h.getText().toString());
                int attack = Integer.parseInt(a.getText().toString());
                int defense = Integer.parseInt(d.getText().toString());
                int ap = Integer.parseInt(AP.getText().toString());
                int RR = Integer.parseInt(dropdown.getSelectedItem().toString());

                JSONObject resp = new JSONObject();
                try {
                    resp.put("name", name);
                    resp.put("health", health);
                    resp.put("attack", attack);
                    resp.put("defense", defense);
                    resp.put("rank", RR);
                    resp.put("ap", ap);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                RequestQueue queue = Volley.newRequestQueue(AddCharacter.this);

                JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, "http://coms-309-058.class.las.iastate.edu:8080/postCharacter", resp,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse (JSONObject response) {
                                n.setText("");
                                h.setText("");
                                a.setText("");
                                d.setText("");
                                AP.setText("");

                                Toast.makeText(AddCharacter.this, "Successfully added " + name, Toast.LENGTH_SHORT).show();

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(AddCharacter.this, "Failed to add " + name, Toast.LENGTH_SHORT).show();
                        error.printStackTrace();

                    }
                });
                queue.add(request);

            }
        });


    }
}