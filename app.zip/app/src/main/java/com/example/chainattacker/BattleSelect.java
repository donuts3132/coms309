package com.example.chainattacker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Random;

public class BattleSelect extends AppCompatActivity {
    int Maxchain;
    int BattlesWon;
    String username;
    int id;
    int userlevel;
    int leaderboardid;
    int mAttack;
    int mHealth;
    String mName;
    int partyid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_battle_select);

        Intent intent = getIntent();
        Maxchain = intent.getIntExtra("Maxchain", -1);
        BattlesWon = intent.getIntExtra("BattlesWon", -1);
        username = intent.getStringExtra("name");
        id = intent.getIntExtra("id", -1);
        leaderboardid = intent.getIntExtra("leaderboardid", -1);
        userlevel = intent.getIntExtra("userlevel", 1);
        partyid = intent.getIntExtra("partyid", -1);

        Button button = (Button) findViewById(R.id.button3);
        Button party = (Button) findViewById(R.id.Toparty);
        ImageButton bronze = (ImageButton) findViewById(R.id.bronze);
        ImageButton silver = (ImageButton) findViewById(R.id.silver);
        ImageButton gold = (ImageButton) findViewById(R.id.gold);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(BattleSelect.this, MainActivity.class);
                intent.putExtra("username", username);
                intent.putExtra("id", id);
                intent.putExtra("leaderboardid", leaderboardid);
                intent.putExtra("userlevel", userlevel);
                intent.putExtra("partyid", partyid);
                startActivity(intent);
            }
        });
        party.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(BattleSelect.this, PartyActivity.class);
                intent.putExtra("username", username);
                intent.putExtra("id", id);
                intent.putExtra("leaderboardid", leaderboardid);
                intent.putExtra("userlevel", userlevel);
                intent.putExtra("partyid", partyid);
                startActivity(intent);
            }
        });
        bronze.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fetch(1);
            }
        });
        silver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fetch(2);
            }
        });
        gold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fetch(3);
            }
        });

    }
    private void fetch(int a) {
        RequestQueue queue = Volley.newRequestQueue(BattleSelect.this);
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, "http://coms-309-058.class.las.iastate.edu:8080/getRankMonster/" + a, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse (JSONObject response) {
                        try {
                            JSONObject x = response;
                            mHealth = x.getInt("health");
                            mAttack = x.getInt("attack");
                            mName = x.getString("name");
                            int mDefense = x.getInt("defense");
                            int xpgain = x.getInt("xpgain");
                            Intent intent = new Intent(BattleSelect.this, Battle.class);
                            intent.putExtra("username", username);
                            intent.putExtra("id", id);
                            intent.putExtra("mName", mName);
                            intent.putExtra("mHealth", mHealth);
                            intent.putExtra("mAttack", mAttack);
                            intent.putExtra("Maxchain", Maxchain);
                            intent.putExtra("BattlesWon", BattlesWon);
                            intent.putExtra("leaderboardid", leaderboardid);
                            intent.putExtra("userlevel", userlevel);
                            intent.putExtra("mRank", a);
                            intent.putExtra("mDefense", mDefense);
                            intent.putExtra("xpgain", xpgain);
                            intent.putExtra("partyid", partyid);
                            startActivity(intent);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


                error.printStackTrace();

            }
        });
        queue.add(request);

    }
}
