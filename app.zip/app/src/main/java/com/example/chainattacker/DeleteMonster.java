package com.example.chainattacker;

import static java.lang.Integer.parseInt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DeleteMonster extends AppCompatActivity {
    String username;
    int id;
    int leaderboardid;
    int userlevel;
    int Mid;
    int partyid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_monster);

        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        id = intent.getIntExtra("id", -1);
        leaderboardid = intent.getIntExtra("leaderboardid", -1);
        userlevel = intent.getIntExtra("userlevel", 1);
        Mid = intent.getIntExtra("Mid", -1);
        partyid = intent.getIntExtra("partyid", -1);

        Button back = (Button) findViewById(R.id.ContinueDM);
        Button SNUL = (Button) findViewById(R.id.SNM);
        Button DM = (Button) findViewById(R.id.Delete);

        updateDisplay();


        DM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RequestQueue queue = Volley.newRequestQueue(DeleteMonster.this);
                StringRequest requesto = new StringRequest(Request.Method.DELETE, "http://coms-309-058.class.las.iastate.edu:8080/deleteMonster/" + Mid,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse (String response) {
                                Toast.makeText(DeleteMonster.this, "Successfully Deleted", Toast.LENGTH_SHORT).show();
                                Intent intent1 = new Intent(DeleteMonster.this, TesterSettings.class);
                                intent1.putExtra("username", username);
                                intent1.putExtra("id", id);
                                intent1.putExtra("leaderboardid", leaderboardid);
                                intent1.putExtra("userlevel", userlevel);
                                intent1.putExtra("partyid", partyid);
                                startActivity(intent1);

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(DeleteMonster.this, "Failed Delete", Toast.LENGTH_SHORT).show();

                        error.printStackTrace();

                    }
                });
                queue.add(requesto);
            }
        });

        SNUL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(DeleteMonster.this, SelectMonster.class);
                intent1.putExtra("username", username);
                intent1.putExtra("id", id);
                intent1.putExtra("leaderboardid", leaderboardid);
                intent1.putExtra("userlevel", userlevel);
                intent1.putExtra("whereto", 1);
                intent1.putExtra("partyid", partyid);
                startActivity(intent1);
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(DeleteMonster.this, TesterSettings.class);
                intent1.putExtra("username", username);
                intent1.putExtra("id", id);
                intent1.putExtra("leaderboardid", leaderboardid);
                intent1.putExtra("userlevel", userlevel);
                intent1.putExtra("partyid", partyid);
                startActivity(intent1);
            }
        });
    }
    private void updateDisplay() {
        TextView display = (TextView) findViewById(R.id.DMDisplay);
        TextView currentl = (TextView) findViewById(R.id.currentMdisplay);
        RequestQueue queue = Volley.newRequestQueue(DeleteMonster.this);

        //need to get leaderboard entry here
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, "http://coms-309-058.class.las.iastate.edu:8080/Monster/" + Mid, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse (JSONObject response) {
                        JSONObject a = response;
                        try{
                            display.setText("Stats of " + response.getString("name") + ":");
                            String z = response.get("health").toString();
                            String y = response.get("attack").toString();
                            String x = response.get("defense").toString();
                            String w = response.get("xpgain").toString();
                            String v = response.get("rankRange").toString();
                            currentl.setText("Health: " + z + "\nAttack: " + y + "\nDefense: " + x + "\nXP gain: " + w + "\nRank Range: " + v);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                error.printStackTrace();

            }
        });
        queue.add(request);


    }
}