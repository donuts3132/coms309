package com.example.chainattacker;

import static java.lang.Integer.parseInt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Leaderboard extends AppCompatActivity  {
    int leaderboardid;
    int id;
    String username;
    JSONArray a;
    JSONArray b;
    int userlevel;
    int partyid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);

        Intent intent = getIntent();
        leaderboardid = intent.getIntExtra("leaderboardid", -1);
        id = intent.getIntExtra("id", -1);
        username = intent.getStringExtra("username");
        userlevel = intent.getIntExtra("userlevel", -1);
        partyid = intent.getIntExtra("partyid", -1);


        //need to sort this still and possibly get usernames
        RequestQueue queue =   Volley.newRequestQueue(getApplicationContext());

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, "http://coms-309-058.class.las.iastate.edu:8080/getAll", null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                b = response;
                sort("mostbattlesWon");



            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        String url = "http://coms-309-058.class.las.iastate.edu:8080/getAllLeaderboard";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                a = response;
                queue.add(request);



            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        queue.add(jsonArrayRequest);



        Button chain = (Button) findViewById(R.id.SortbyMaxchain);
        Button Battles = (Button) findViewById(R.id.SortyByBattles);
        Button button = (Button) findViewById(R.id.button2);

        Battles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sort("mostbattlesWon");
            }
        });

        chain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sort("maxchain");
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(Leaderboard.this, MainActivity.class);
                intent1.putExtra("leaderboardid", leaderboardid);
                intent1.putExtra("id", id);
                intent1.putExtra("username", username);
                intent1.putExtra("userlevel", userlevel);
                intent1.putExtra("partyid", partyid);
                startActivity(intent1);
            }
        });

    }
    private void sort(String sortby) {
        TextView row1a = (TextView) findViewById(R.id.row1a);
        TextView row1b = (TextView) findViewById(R.id.row1b);
        TextView row1c = (TextView) findViewById(R.id.row1c);
        TextView row2a = (TextView) findViewById(R.id.row2a);
        TextView row2b = (TextView) findViewById(R.id.row2b);
        TextView row2c = (TextView) findViewById(R.id.row2c);
        TextView row3a = (TextView) findViewById(R.id.row3a);
        TextView row3b = (TextView) findViewById(R.id.row3b);
        TextView row3c = (TextView) findViewById(R.id.row3c);
        TextView row4a = (TextView) findViewById(R.id.row4a);
        TextView row4b = (TextView) findViewById(R.id.row4b);
        TextView row4c = (TextView) findViewById(R.id.row4c);
        TextView row5a = (TextView) findViewById(R.id.row5a);
        TextView row5b = (TextView) findViewById(R.id.row5b);
        TextView row5c = (TextView) findViewById(R.id.row5c);
        TextView row6a = (TextView) findViewById(R.id.row6a);
        TextView row6b = (TextView) findViewById(R.id.row6b);
        TextView row6c = (TextView) findViewById(R.id.row6c);
        TextView row7a = (TextView) findViewById(R.id.row7a);
        TextView row7b = (TextView) findViewById(R.id.row7b);
        TextView row7c = (TextView) findViewById(R.id.row7c);
        TextView row8a = (TextView) findViewById(R.id.row8a);
        TextView row8b = (TextView) findViewById(R.id.row8b);
        TextView row8c = (TextView) findViewById(R.id.row8c);
        try {
            for (int i = 0; i < a.length() - 1; i++) {
                for (int j = 0; j < a.length() - i - 1; j++) {
                    JSONObject d = (JSONObject) a.get(j);
                    JSONObject c = (JSONObject) a.get(j + 1);
                    int l = parseInt(d.get(sortby).toString());
                    int z = parseInt(c.get(sortby).toString());
                    if (l < z) {
                        JSONObject temp = d;
                        a.put(j, c);
                        a.put(j + 1, temp);
                    }
                }
            }
            for (int i = 0; i < a.length(); i++) {
                if (i == 0) {
                    JSONObject object = (JSONObject) a.get(i);
                    String x = getusername(i);
                    String y = object.get("maxchain").toString();
                    String z = object.get("mostbattlesWon").toString();
                    row1a.setText(x);
                    row1b.setText(y);
                    row1c.setText(z);
                }
                if (i == 1) {
                    JSONObject object = (JSONObject) a.get(i);
                    String x = getusername(i);
                    String y = object.get("maxchain").toString();
                    String z = object.get("mostbattlesWon").toString();
                    row2a.setText(x);
                    row2b.setText(y);
                    row2c.setText(z);
                }
                if (i == 2) {
                    JSONObject object = (JSONObject) a.get(i);
                    String x = getusername(i);
                    String y = object.get("maxchain").toString();
                    String z = object.get("mostbattlesWon").toString();
                    row3a.setText(x);
                    row3b.setText(y);
                    row3c.setText(z);
                }
                if (i == 3) {
                    JSONObject object = (JSONObject) a.get(i);
                    String x = getusername(i);
                    String y = object.get("maxchain").toString();
                    String z = object.get("mostbattlesWon").toString();
                    row4a.setText(x);
                    row4b.setText(y);
                    row4c.setText(z);
                }
                if (i == 4) {
                    JSONObject object = (JSONObject) a.get(i);
                    String x = getusername(i);
                    String y = object.get("maxchain").toString();
                    String z = object.get("mostbattlesWon").toString();
                    row5a.setText(x);
                    row5b.setText(y);
                    row5c.setText(z);
                }
                if (i == 5) {
                    JSONObject object = (JSONObject) a.get(i);
                    String x = getusername(i);
                    String y = object.get("maxchain").toString();
                    String z = object.get("mostbattlesWon").toString();
                    row6a.setText(x);
                    row6b.setText(y);
                    row6c.setText(z);
                }
                if (i == 6) {
                    JSONObject object = (JSONObject) a.get(i);
                    String x = getusername(i);
                    String y = object.get("maxchain").toString();
                    String z = object.get("mostbattlesWon").toString();
                    row7a.setText(x);
                    row7b.setText(y);
                    row7c.setText(z);
                }
                if (i == 7) {
                    JSONObject object = (JSONObject) a.get(i);
                    String x = getusername(i);
                    String y = object.get("maxchain").toString();
                    String z = object.get("mostbattlesWon").toString();
                    row8a.setText(x);
                    row8b.setText(y);
                    row8c.setText(z);
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    private String getusername(int i) {
        try {
            JSONObject x = (JSONObject) a.get(i);
            int y = x.getInt("boardId");
            for (int j = 0; j < b.length(); j++) {
                JSONObject r = (JSONObject) b.get(j);
                JSONObject t = r.getJSONObject("leaderboard");
                int z = t.getInt("boardId");
                if (z == y) {
                    return r.get("name").toString();
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return "Failed to get username";
    }



}
