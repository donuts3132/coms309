package com.example.chainattacker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Random;

public class Rewards extends AppCompatActivity {
    //still need to update information here
    int Maxchain;
    int CurrChain;
    int BattlesWon;
    int Result;
    String username;
    int id;
    int leaderboardid;
    int userlevel;
    JSONArray charsInit = new JSONArray();
    int mRank;
    String newcName = "";
    int xpgain;
    String[] charNames = new String[6];
    int[] charId = new int[6];
    int partyid;
    int counter = 0;

    RequestQueue queue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rewards);

        Intent intent = getIntent();
        Maxchain = intent.getIntExtra("Maxchain", -1);
        CurrChain = intent.getIntExtra("CurrChain", -1);
        BattlesWon = intent.getIntExtra("BattlesWon", -1);
        username = intent.getStringExtra("username");
        id = intent.getIntExtra("id", -1);
        Result = intent.getIntExtra("Result", -1);
        leaderboardid = intent.getIntExtra("leaderboardid", -1);
        userlevel = intent.getIntExtra("userlevel", 1);
        mRank = intent.getIntExtra("mRank", -1);
        xpgain = intent.getIntExtra("xpgain", -1);
        charNames = intent.getStringArrayExtra("charNames");
        charId = intent.getIntArrayExtra("charId");
        partyid = intent.getIntExtra("partyid", -1);
        Button button = (Button) findViewById(R.id.Continuebutton);


        queue = Volley.newRequestQueue(Rewards.this);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Rewards.this, MainActivity.class);
                intent.putExtra("username", username);
                intent.putExtra("id", id);
                intent.putExtra("leaderboardid", leaderboardid);
                intent.putExtra("userlevel", userlevel);
                intent.putExtra("partyid", partyid);
                startActivity(intent);
                finish();
            }
        });
    }
    @Override
    protected void onResume() {
        super.onResume();

        Intent intent = getIntent();
        Maxchain = intent.getIntExtra("Maxchain", -1);
        CurrChain = intent.getIntExtra("CurrChain", -1);
        BattlesWon = intent.getIntExtra("BattlesWon", -1);
        username = intent.getStringExtra("username");
        id = intent.getIntExtra("id", -1);
        Result = intent.getIntExtra("Result", -1);
        leaderboardid = intent.getIntExtra("leaderboardid", -1);
        userlevel = intent.getIntExtra("userlevel", 1);
        mRank = intent.getIntExtra("mRank", 0);
        xpgain = intent.getIntExtra("xpgain", 0);
        charNames = intent.getStringArrayExtra("charNames");
        charId = intent.getIntArrayExtra("charId");
        partyid = intent.getIntExtra("partyid", -1);

        TextView bcr = (TextView) findViewById(R.id.bcr);
        TextView mcr = (TextView) findViewById(R.id.mcr);
        TextView bwr = (TextView) findViewById(R.id.bwr);
        TextView textView = (TextView) findViewById(R.id.textView3);
        Button button = (Button) findViewById(R.id.Continuebutton);
        queue = Volley.newRequestQueue(Rewards.this);
        counter = 0;
        if (Maxchain < CurrChain) {
            Maxchain = CurrChain;
        }

        bcr.setText("Biggest Chain: " + CurrChain);
        mcr.setText("Max Chain: " + Maxchain);
        bwr.setText("Battles Won: " + BattlesWon);

        if (Result == 1) {
            textView.setText("Victory!");
            registerChar();
            levelUp();
        }
        else if (Result == 0) {
            textView.setText("Defeat");
        }

        JSONObject respObj = new JSONObject();
        try {
            respObj.put("maxchain", Maxchain);
            respObj.put("mostbattleswon", BattlesWon);
            respObj.put("boardId", leaderboardid);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        queue = Volley.newRequestQueue(Rewards.this);
        JsonObjectRequest requesto = new JsonObjectRequest(Request.Method.PUT, "http://coms-309-058.class.las.iastate.edu:8080/updateLeaderboard/" + leaderboardid, respObj,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse (JSONObject response) {

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


                error.printStackTrace();

            }
        });
        queue.add(requesto);
    }

    private void registerChar() {
        JSONArray UC = new JSONArray();

        String url = "http://coms-309-058.class.las.iastate.edu:8080/getAllCharacters";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject y = (JSONObject) response.get(i);
                        if (y.getInt("rank") == mRank) {
                            charsInit.put(y);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
                for (int i = 0; i < response.length(); i++) {
                    for (int j = 0; j < UC.length(); j++) {
                        try {
                            JSONObject y = (JSONObject) charsInit.get(i);
                            JSONObject z = (JSONObject) UC.get(i);
                            if (y.getString("name") == z.getString("name")) {
                                charsInit.remove(i);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (charsInit.length() != 0) {
                    generateUserChar();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        url = "http://coms-309-058.class.las.iastate.edu:8080/player/userCharacters/" + id;
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject y = (JSONObject) response.get(i);
                        if (y.getInt("rank") == mRank) {
                            UC.put(y);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
                queue.add(jsonArrayRequest);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        queue.add(request);

    }
    private void generateUserChar () {
        Random rand = new Random();
        int j = rand.nextInt(charsInit.length());
        JSONObject resp = new JSONObject();


        try {
            JSONObject l = charsInit.getJSONObject(j);
            charsInit.remove(j);
            newcName = l.getString("name");
            resp.put("name", l.getString("name"));
            resp.put("health", l.getInt("health"));
            resp.put("attack", l.getInt("attack"));
            resp.put("defense", l.getInt("defense"));
            resp.put("ap", l.getInt("ap"));
            resp.put("level", 1);
            resp.put("xp", 0);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestQueue queue = Volley.newRequestQueue(Rewards.this);

        //need to get leaderboard entry here
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, "http://coms-309-058.class.las.iastate.edu:8080/newUsersCharacter", resp,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse (JSONObject response) {
                        JSONObject a = response;
                        try {
                            int x = response.getInt("id");
                            connectUCtoP(x, newcName);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                error.printStackTrace();

            }
        });
        queue.add(request);
    }

    private void connectUCtoP (int i, String s) {

        //need to get leaderboard entry here
        StringRequest request = new StringRequest(Request.Method.PUT, "http://coms-309-058.class.las.iastate.edu:8080/Players/" + id + "/UsersCharacter/" + i,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse (String response) {
                        Toast.makeText(Rewards.this, "New Character Unlocked: " + s, Toast.LENGTH_SHORT).show();


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                error.printStackTrace();

            }
        });
        queue.add(request);
    }

    private void levelUp () {
        String url = "http://coms-309-058.class.las.iastate.edu:8080/levelUpCharacter/" + charId[counter] + "/" + xpgain;
        //need to get leaderboard entry here
        StringRequest request = new StringRequest(Request.Method.PUT, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse (String response) {
                        String s = response;
                        String t = charNames[counter] + ": +" + xpgain + "xp, " + response + "\n";
                        TextView textView = (TextView) findViewById(R.id.textView30);
                        textView.append(t);
                        counter++;
                        if (counter <= 5) {
                            levelUp();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                error.printStackTrace();

            }
        });
        queue.add(request);
    }
}
