package com.example.chainattacker;

import static java.lang.Integer.parseInt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

public class changeleaderboard extends AppCompatActivity {
    String username;
    int id;
    int leaderboardid;
    int userlevel;
    int Sid;
    int Slid;
    String Susername;
    RequestQueue queue;
    int partyid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_changeleaderboard);

        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        id = intent.getIntExtra("id", -1);
        leaderboardid = intent.getIntExtra("leaderboardid", -1);
        userlevel = intent.getIntExtra("userlevel", 1);
        Susername = intent.getStringExtra("Susername");
        Sid = intent.getIntExtra("Sid", -1);
        Slid = intent.getIntExtra("Slid", -1);
        partyid = intent.getIntExtra("partyid", -1);

        Button back = (Button) findViewById(R.id.backul);
        Button SNUL = (Button) findViewById(R.id.SNUL);
        EditText MC = (EditText) findViewById(R.id.editChain);
        EditText BW = (EditText) findViewById(R.id.editBattles);
        Button updateLeaderboard = (Button) findViewById(R.id.button6);
        queue = Volley.newRequestQueue(changeleaderboard.this);
        updateDisplay();


        updateLeaderboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                JSONObject respObj = new JSONObject();
                try {
                    respObj.put("maxchain", parseInt(MC.getText().toString()));
                    respObj.put("mostbattleswon", parseInt(BW.getText().toString()));
                    respObj.put("boardId", Slid);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                JsonObjectRequest requesto = new JsonObjectRequest(Request.Method.PUT, "http://coms-309-058.class.las.iastate.edu:8080/updateLeaderboard/" + Slid, respObj,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse (JSONObject response) {
                                updateDisplay();
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {


                        error.printStackTrace();

                    }
                });
                queue.add(requesto);
            }
        });

        SNUL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(changeleaderboard.this, Select.class);
                intent1.putExtra("username", username);
                intent1.putExtra("id", id);
                intent1.putExtra("leaderboardid", leaderboardid);
                intent1.putExtra("userlevel", userlevel);
                intent1.putExtra("partyid", partyid);
                intent1.putExtra("whereto", 2);
                startActivity(intent1);
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(changeleaderboard.this, AdminSettings.class);
                intent1.putExtra("username", username);
                intent1.putExtra("id", id);
                intent1.putExtra("leaderboardid", leaderboardid);
                intent1.putExtra("userlevel", userlevel);
                intent1.putExtra("partyid", partyid);
                startActivity(intent1);
            }
        });
    }
    private void updateDisplay() {
        TextView display = (TextView) findViewById(R.id.ulDisplay);
        TextView currentl = (TextView) findViewById(R.id.currentldisplay);
        display.setText("Leaderboard of the user " + Susername + ":");

        //need to get leaderboard entry here
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, "http://coms-309-058.class.las.iastate.edu:8080/leaderboard/" + Slid, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse (JSONObject response) {
                        JSONObject a = response;
                        try{
                            String y = response.get("mostbattlesWon").toString();
                            String z = response.get("maxchain").toString();
                            currentl.setText("Max Chain: " + z + "\nBattles Won: " + y);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                error.printStackTrace();

            }
        });
        queue.add(request);
    }
}