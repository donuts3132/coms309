package com.example.chainattacker;

public abstract class UnitParty {

    int hp;
    int atk;
    int numbid;
    String name;

    public UnitParty(int hp, int atk, int numbid, String name) {

        this.hp = hp;
        this.atk = atk;
        this.numbid = numbid;
        this.name = name;
    }

    public UnitParty(){
    }

    public int giveHP(UnitParty unit) {

        return unit.hp;
    }

    public int giveATK(UnitParty unit) {

        return unit.atk;
    }

    public int giveID(UnitParty unit) {

        return unit.numbid;
    }
}

//class Orange extends UnitParty {
//
//    Orange() {
//
//        super(10, 10, 1, "Orange");
//    }
//}
//
//class Book extends UnitParty {
//
//    Book() {
//
//        super(10, 10, 2, "Book");
//    }
//}
//
//class Hairbrush extends UnitParty {
//
//    Hairbrush() {
//
//        super(10, 10, 3, "Hairbrush");
//    }
//}
//
//class Cat extends UnitParty{
//
//    Cat() {
//
//        super(10, 10, 4, "Cat");
//    }
//}
//
//class Owl extends UnitParty{
//
//    Owl() {
//
//        super(10, 10, 5, "Owl");
//    }
//}
//
//class Rambutan extends UnitParty{
//
//    Rambutan() {
//
//        super(10, 10, 6, "Rambutan");
//    }
//}