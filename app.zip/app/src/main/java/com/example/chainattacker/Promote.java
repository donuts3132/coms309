package com.example.chainattacker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.ArrayList;

public class Promote extends AppCompatActivity {
    String username;
    int id;
    int leaderboardid;
    int userlevel;
    int Sid;
    String Susername;
    int Sul;
    int j;
    int partyid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_promote);

        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        id = intent.getIntExtra("id", -1);
        leaderboardid = intent.getIntExtra("leaderboardid", -1);
        userlevel = intent.getIntExtra("userlevel", 1);
        Sid = intent.getIntExtra("Sid", -1);
        Susername = intent.getStringExtra("Susername");
        Sul = intent.getIntExtra("Sul", -1);
        partyid = intent.getIntExtra("partyid", -1);

        Button backp = (Button) findViewById(R.id.backp);

        Button updatelevel = (Button) findViewById(R.id.updatelevel);

        Button SNUP = (Button) findViewById(R.id.SNUP);

        setDisplay();




        //get the spinner from the xml.
        Spinner dropdown = findViewById(R.id.spinner);
//create a list of items for the spinner.
        String[] items = new String[]{"Player", "BetaTester", "Admin"};
//create an adapter to describe how the items are displayed, adapters are used in several places in android.
//There are multiple variations of this, but this is the basic variant.
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
//set the spinners adapter to the previously created one.
        dropdown.setAdapter(adapter);




        backp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(Promote.this, AdminSettings.class);
                intent1.putExtra("username", username);
                intent1.putExtra("id", id);
                intent1.putExtra("leaderboardid", leaderboardid);
                intent1.putExtra("userlevel", userlevel);
                startActivity(intent1);
            }
        });

        SNUP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(Promote.this, Select.class);
                intent1.putExtra("username", username);
                intent1.putExtra("id", id);
                intent1.putExtra("leaderboardid", leaderboardid);
                intent1.putExtra("userlevel", userlevel);
                intent1.putExtra("whereto", 1);
                intent1.putExtra("partyid", partyid);
                startActivity(intent1);
            }
        });

        updatelevel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RequestQueue queue = Volley.newRequestQueue(Promote.this);

                String s = (String) dropdown.getSelectedItem();
                if (s.equals("Admin")) {
                    j = 3;
                }
                else if (s.equals("BetaTester")) {
                   j = 2;
                }
                else if (s.equals("Player")) {
                    j = 1;
                }
                StringRequest x = new StringRequest(Request.Method.POST, "http://coms-309-058.class.las.iastate.edu:8080/changeLevel/" +  Sid + "/" + j,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse (String response) {
                                    Toast.makeText(Promote.this, "Success", Toast.LENGTH_SHORT).show();
                                    Sul = j;
                                    if (Sid == id) {
                                        userlevel = Sul;
                                    }
                                    setDisplay();

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Promote.this, "Failed to contact server", Toast.LENGTH_SHORT).show();
                        error.printStackTrace();

                    }
                });
                queue.add(x);
            }
        });
    }
    private void setDisplay() {
        TextView current = (TextView) findViewById(R.id.currentpromote);
        String s = "";
        if (Sul == 1) {
            s = "player";
        }
        else if (Sul == 2) {
            s = "BetaTester";
        }
        else if (Sul == 3) {
            s = "Administrator";
        }

        current.setText(Susername + " is currently a " + s);
    }
}