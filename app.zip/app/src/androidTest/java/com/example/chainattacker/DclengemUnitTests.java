package com.example.chainattacker;

import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.hamcrest.Matcher;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.junit.Rule;


import androidx.test.rule.ActivityTestRule;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isAssignableFrom;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.core.StringEndsWith.endsWith;
import static java.lang.Integer.parseInt;

import android.view.View;
import android.widget.TextView;


/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class DclengemUnitTests {
    private static final int SIMULATED_DELAY_MS = 500;

    @Rule   // needed to launch the activity
    public ActivityTestRule<LoginActivity> activityRule = new ActivityTestRule<>(LoginActivity.class);




    /**
     * Start the server and run this test
     */
    @Test
    public void changeUsername(){
        String testString = "test123";
        String resultString = "Current Username: test123";
        // Type in testString and send request
        onView(withId(R.id.Username))
                .perform(typeText(testString), closeSoftKeyboard());
        onView(withId(R.id.Password)).perform(typeText("test"), closeSoftKeyboard());

        onView(withId(R.id.login)).perform(click());
        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }

        onView(withId(R.id.Settings)).perform(click());
        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        onView(withId(R.id.changeu)).perform(click());
        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        onView(withId(R.id.newu)).perform(typeText("test123"), closeSoftKeyboard());
        onView(withId(R.id.changeu)).perform(click());

        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
        }


        // Verify that volley returned the correct value
        onView(withId(R.id.currentu)).check(matches(withText(endsWith(resultString))));

        onView(withId(R.id.backcu)).perform(click());
        onView(withId(R.id.logout)).perform(click());

        onView(withId(R.id.Username))
                .perform(typeText(testString), closeSoftKeyboard());
        onView(withId(R.id.Password)).perform(typeText("test"), closeSoftKeyboard());

        onView(withId(R.id.login)).perform(click());
        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }


        // Verify that volley returned the correct value
        onView(withId(R.id.username)).check(matches(withText(endsWith("test123"))));


    }

    /**
     * Start the server and run this test
     */
    @Test
    public void damageMultiplier(){
        String testString = "test123";
        String resultString = "Damage Multiplier: x1.05";
        // Type in testString and send request
        onView(withId(R.id.Username))
                .perform(typeText(testString), closeSoftKeyboard());
        onView(withId(R.id.Password)).perform(typeText("test"), closeSoftKeyboard());

        onView(withId(R.id.login)).perform(click());
        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }

        onView(withId(R.id.battlebutton)).perform(click());
        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        onView(withId(R.id.bronze)).perform(click());
        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        onView(withId(R.id.c1)).perform(click());

        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
        }


        // Verify that volley returned the correct value
        onView(withId(R.id.textView9)).check(matches(withText(endsWith(resultString))));


    }

    /**
     * Start the server and run this test
     */
    @Test
    public void changepassword(){
        String testString = "test123";
        String resultString = "test123";
        // Type in testString and send request
        onView(withId(R.id.Username))
                .perform(typeText(testString), closeSoftKeyboard());
        onView(withId(R.id.Password)).perform(typeText("test"), closeSoftKeyboard());

        onView(withId(R.id.login)).perform(click());
        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }

        onView(withId(R.id.Settings)).perform(click());
        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        onView(withId(R.id.cpass)).perform(click());
        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        onView(withId(R.id.newp)).perform(typeText("test"), closeSoftKeyboard());
        onView(withId(R.id.cpass)).perform(click());
        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
        }
        onView(withId(R.id.backcp)).perform(click());
        onView(withId(R.id.logout)).perform(click());

        onView(withId(R.id.Username))
                .perform(typeText(testString), closeSoftKeyboard());
        onView(withId(R.id.Password)).perform(typeText("test"), closeSoftKeyboard());

        onView(withId(R.id.login)).perform(click());
        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }


        // Verify that volley returned the correct value
        onView(withId(R.id.username)).check(matches(withText(endsWith(resultString))));


    }

    /**
     * Start the server and run this test
     */
    @Test
    public void Leaderboard(){
        String testString = "test123";
        String resultString = "test123";
        // Type in testString and send request
        onView(withId(R.id.Username))
                .perform(typeText(testString), closeSoftKeyboard());
        onView(withId(R.id.Password)).perform(typeText("test"), closeSoftKeyboard());

        onView(withId(R.id.login)).perform(click());
        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }

        onView(withId(R.id.leaderboard)).perform(click());
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException e) {
        }

        // Put thread to sleep to allow volley to handle the request
        try {
            Thread.sleep(SIMULATED_DELAY_MS);
        } catch (InterruptedException z) {

        }


        int[] array = new int[8];
        String s = getText(withId(R.id.row1c));
        try {
            array[0] = parseInt(s);
        }
        catch (Exception e){

        }
        s = getText(withId(R.id.row2c));
        try {
            array[1] = parseInt(s);
        }
        catch (Exception e){

        }
        s = getText(withId(R.id.row3c));
        try {
            array[2] = parseInt(s);
        }
        catch (Exception e){

        }
        s = getText(withId(R.id.row4c));
        try {
            array[3] = parseInt(s);
        }
        catch (Exception e){

        }
        s = getText(withId(R.id.row5c));
        try {
            array[4] = parseInt(s);
        }
        catch (Exception e){

        }
        s = getText(withId(R.id.row6c));
        try {
            array[5] = parseInt(s);
        }
        catch (Exception e){

        }
        s = getText(withId(R.id.row7c));
        try {
            array[6] = parseInt(s);
        }
        catch (Exception e){

        }


        for (int i = 0; i < 8 - 1; i++) {
            for (int j = 0; j < 8 - i - 1; j++) {
                if (array[j] < array[j + 1]) {
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
        }

        String x = String.valueOf(array[0]);




        // Verify that volley returned the correct value
        onView(withId(R.id.row1c)).check(matches(withText(x)));


    }

    String getText(final Matcher<View> matcher) {
        final String[] stringHolder = { null };
        onView(matcher).perform(new ViewAction() {
            @Override
            public Matcher<View> getConstraints() {
                return isAssignableFrom(TextView.class);
            }

            @Override
            public String getDescription() {
                return "getting text from a TextView";
            }

            @Override
            public void perform(UiController uiController, View view) {
                TextView tv = (TextView)view; //Save, because of check in getConstraints()
                stringHolder[0] = tv.getText().toString();
            }
        });
        return stringHolder[0];
    }



}